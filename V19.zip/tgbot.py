from aiogram import Bot, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import Dispatcher
from aiogram.utils.exceptions import Throttled
from aiogram.utils import executor
import logging
import socket
import psutil

# Объект бота
bot = Bot(token="5492155957:AAEcmkfBUN5ntPDlRXbvjsLh8dQNRDQiPiQ")
server = "Infinity Brawl"
status = ""
# Диспетчер для бота
dp = Dispatcher(bot)
#db = DB()
# Включаем логирование, чтобы не пропустить важные сообщения
logging.basicConfig(level=logging.INFO)
adminid = [5210425575]

async def anti_flood(*args, **kwargs):
    m = args[0]
    await message.reply("Не флуди :)")

# Хэндлер на команду /start
@dp.message_handler(commands="start")
async def start(message: types.Message):
    	await message.reply(f"Привет! Я бот сервера: {server}!\nУзнать мои команды: /help")
    	
# Хэндлер на команду /help
@dp.message_handler(commands="help")
async def help(message: types.Message):
    	await message.reply(f"Мои команды:\n/status - узнать статус сервера")
    	
# Хэндлер на команду /status
@dp.message_handler(commands="status")
async def help(message: types.Message):
    	try:
    		s = socket.socket()
    		s.connect(("185.104.248.10", 9339))
    		status = "ВКЛЮЧЕН✅"
    		await message.reply(f"СТАТУС СЕРВЕРА: {status}\nRAM: {psutil.virtual_memory().percent}%\nCPU: {psutil.cpu_percent()}%")
    	except Exception as e:
    		status = "ВЫКЛЮЧЕН❌"
    		await message.reply(f"СТАТУС СЕРВЕРА: {status}\nRAM: 0%\nCPU: 0%")


if __name__ == "__main__":
    # Запуск бота
    executor.start_polling(dp)