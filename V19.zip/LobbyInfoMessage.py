from Utils.Writer import Writer  # Доданий імпорт
import time
import socket
import psutil

class LobbyInfoMessage(Writer):
    def __init__(self, client, player, count):
        super().__init__(client)
        self.id = 23457
        self.player = player
        self.count = count
        self.ping, self.ping_icon = self.measure_ping()

    def measure_ping(self):
        try:
            start_time = time.time()
            # Встановлення з'єднання з сервером за допомогою TCP
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect(("95.181.151.250", 80))  # Замініть "your_server_ip" та "your_server_port" на реальні значення
            end_time = time.time()
            # Вимір часу з'єднання
            ping_time = (end_time - start_time) * 1000  # Перетворення в мілісекунди

            # Визначення піктограми пінгу
            if 0 <= ping_time <= 59:
                ping_icon = ' ▂▄▅  '
            elif 60 <= ping_time <= 99:
                ping_icon = ' ▂▄▅  '
            elif 100 <= ping_time <= 199:
                ping_icon = ' ▂▄  '
            elif 200 <= ping_time <= 299:
                ping_icon = ' ▂  '
            elif ping_time >= 300:
                ping_icon = ' ▁  '
            else:
                ping_icon = '      '

            return ping_time, ping_icon
        except Exception as e:
            print("Сталася помилка при вимірюванні пінгу:", str(e))
            return -1, ''

    def encode(self):
        self.writeVint(1)
        ping_display = f"Пинг: {self.ping_icon} {int(self.ping)}ms"
        self.writeString(f"Gale Brawl | PROD\nТелеграм: @GaleBrawll\n{time.asctime()}\nRAM: %\nCPU: %\n{ping_display}")
        
        self.writeVint(1)
        for x in range(0):
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(1)