from Packets.Messages.Server.Alliance.Alliance_Chat_Server_Message import AllianceChatServerMessage
from Packets.Messages.Server.AllianceBot.Alliance_Bot_Chat_Server_Message import AllianceBotChatServerMessage
from Packets.Messages.Server.Out_Of_Sync_Message import OutOfSyncMessage
from Database.DatabaseManager import DataBase

from Utils.Reader import BSMessageReader
from Utils.Helpers import Helpers


class Chat_Message(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client
        self.bot_msg = ''
        self.send_ofs = False
        self.IsAcmd = False

    def decode(self):
        self.msg = self.read_string()

        if self.msg.lower() == '/stats':
            self.bot_msg = f'Server status:\nBuild version: 1.1 (for v26.165)\nFingerprint SHA: {self.player.patch_sha}'
            self.IsAcmd = True

        elif self.msg.lower() == '/reset':
            self.send_ofs = True
            DataBase.replaceValue(self, 'gold', 99999)
            DataBase.replaceValue(self, 'gems', 99999)
            DataBase.replaceValue(self, 'tickets', 99999)
            self.IsAcmd = True

        elif self.msg.lower().startswith('/gems'):
            try:
                newGems = self.msg.split(" ", 4)[1:]
                DataBase.replaceValue(self, 'gems', int(newGems[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass

        elif self.msg.lower().startswith('/gold'):
            try:
                newGold = self.msg.split(" ", 4)[1:]
                DataBase.replaceValue(self, 'gold', int(newGold[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass

        elif self.msg.lower().startswith('/tickets'):
            try:
                newTickets = self.msg.split(" ", 7)[1:]
                DataBase.replaceValue(self, 'tickets', int(newTickets[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass

        elif self.msg.lower().startswith('/starpoints'):
            try:
                newStarpoints = self.msg.split(" ", 10)[1:]
                DataBase.replaceValue(self, 'starpoints', int(newStarpoints[0]))
                self.send_ofs = True
                self.IsAcmd = True
            except:
                pass
            
        elif self.msg.lower().startswith('/theme'):
            try:
                newDudka = self.msg.split(" ", 4)[1:]
                self.player.theme_id = newDudka[0]
                self.send_ofs = False
                self.IsAcmd = True
            except:
                pass
                
        elif self.msg.lower() == '/theme':
            self.bot_msg = 'Перещайдите/войдите в боц и выйдете чтобы ищмкнить тему!'
            self.IsAcmd = True

        else:
            self.IsAcmd = False



    def process(self):
        if self.IsAcmd == False:
            DataBase.Addmsg(self, 2, 0, self.player.low_id, self.player.name, self.player.club_role, self.msg)
            DataBase.loadClub(self, self.player.club_low_id)
            for i in self.plrids:
                AllianceChatServerMessage(self.client, self.player, self.msg).sendWithLowID(i)

        if self.bot_msg != '':
            AllianceBotChatServerMessage(self.client, self.player, self.bot_msg).send()

        if self.send_ofs:
            OutOfSyncMessage(self.client, self.player, 'Changes have been applied').send()