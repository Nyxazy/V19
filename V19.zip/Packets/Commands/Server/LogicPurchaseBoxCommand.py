from Database.DatabaseManager import DataBase
from Logic.Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand

from Util.Reader import BSMessageReader

class LogicPurchaseBoxCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.player.box_id = self.read_Vint()

    def process(self):
        if self.player.box_id == 5:
            self.player.brawl_boxes -= 100
            DataBase.replaceValue(self, 'brawlBoxes', self.player.brawl_boxes)
            LogicBoxDataCommand(self.client, self.player, 0, 1).send()
        elif self.player.box_id == 4:
            self.player.big_boxes -= 10
            DataBase.replaceValue(self, 'bigBoxes', self.player.big_boxes)
            LogicBoxDataCommand(self.client, self.player, 0, 1).send()
        elif self.player.box_id == 3:
            self.player.gems -= 80
            DataBase.replaceValue(self, 'gems', self.player.gems)
            LogicBoxDataCommand(self.client, self.player, 0, 1).send()
        elif self.player.box_id == 1:
            self.player.gems -= 30
            DataBase.replaceValue(self, 'gems', self.player.gems)
            LogicBoxDataCommand(self.client, self.player, 0, 1).send()