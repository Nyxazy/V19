from Database.DatabaseManager import DataBase

from Utils.Writer import Writer

class ShopResponse(Writer):
	def __init__(self, client, player, state, data, count):
		super().__init__(client)
		self.id = 24111
		self.player = player
		self.state = state
		self.count = count
		self.data= data

	def encode(self):
		self.writeVint(203) # CommandID
		self.writeVint(0)   # Unknown
		self.writeVint(1)   # Unknown
		self.writeVint(100)  # BoxID
		self.writeVint(1) # Reward count
		self.writeVint(self.count)                           # Reward amount
		if self.data["id"]==6:
			self.writeScId(16, self.data["scid"]) # CsvI
		else:
			self.writeVint(0)
		self.writeVint(self.data["id"])                           # Reward
		if self.data["id"] == 9:
			self.writeScId(29, self.data["skin"])#skin
		else:
			self.writeVint(0)
		if self.data["id"] == 5:
			self.writeScId(23, self.data["skin"])
		else:
			self.writeVint(0)
		self.writeVint(0)
		if self.state == 1:
			self.writeVint(self.player.trophy_road + 1)
		else:
			for i in range(13):
				self.writeVint(0)