from Database.DatabaseManager import DataBase
from Packets.Commands.Server.LogicBoxDataCommand import LogicBoxDataCommand
from Packets.Commands.Server.LogicBrawlerDataCommand import LogicBrawlerDataCommand
from Packets.Messages.Server.Login.LoginFailedMessage import LoginFailedMessage
from Packets.Commands.Server.ShopResponse import ShopResponse
from Packets.Commands.Server.LogicTicketsDataCommand import LogicTicketsDataCommand

from Utils.Reader import BSMessageReader

class LogicClaimRankUpRewardCommand(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.read_Vint()
        self.brawlerID = self.read_Vint()

    def process(self):
        if self.player.trophy_road in [1, 3, 5, 11, 14, 18, 20, 27, 31, 33, 37, 40, 42, 49, 52, 58, 60, 62, 67, 70, 73, 77, 79, 80, 84, 85, 89, 93]:
            if self.player.trophy_road in [1, 3, 5, 11, 14, 20, 27, 33, 37, 40, 42, 49, 52, 62, 67, 77, 79, 84]:
                self.player.box_id = 0
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
            elif self.player.trophy_road in [18, 31, 58, 73]:
                self.player.box_id = 1
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
            elif self.player.trophy_road in [60, 70, 80, 85, 89, 93]:
                self.player.box_id = 3
                LogicBoxDataCommand(self.client, self.player, 1, 1).send()
        elif self.player.trophy_road in [16, 19, 23, 26, 29, 32, 36, 39, 41, 44, 46, 48, 50, 54, 57, 63, 66, 69, 71, 74, 78, 81, 83, 86, 87, 88, 90, 91, 92, 94]:
            if self.player.trophy_road in [16, 19, 23, 26, 29, 32, 36, 39, 44, 46, 50, 54, 57, 66, 69, 71, 74, 81]:
                count = 50
                ShopResponse(self.client, self.player, 1, {"id": 7}, count).send()
                self.player.gold += count
                DataBase.replaceValue(self, 'gold', self.player.gold)
            elif self.player.trophy_road in [41, 63, 78, 83, 86, 88, 90, 92, 94]:
                count = 150
                ShopResponse(self.client, self.player, 1, {"id": 7}, count).send()
                self.player.gold += count
                DataBase.replaceValue(self, 'gold', self.player.gold)
            elif self.player.trophy_road in [48, 87, 91]:
                count = 300
                ShopResponse(self.client, self.player, 1, {"id": 7}, count).send()
                self.player.gold += count
                DataBase.replaceValue(self, 'gold', self.player.gold)
        elif self.player.trophy_road in [4, 8, 12, 21]:
            DataBase.loadAccount(self)
        elif self.player.trophy_road in [7, 51]:
            if self.player.trophy_road == 7:
                ShopResponse(self.client, self.player, 1, {"id": 2}, 200).send()
                self.player.tokensdoubler += 200
                DataBase.replaceValue(self, 'tokensdoubler', self.player.tokensdoubler)
            elif self.player.trophy_road == 51:
                ShopResponse(self.client, self.player, 1, {"id": 2}, 600).send()
                self.player.tokensdoubler += 600
                DataBase.replaceValue(self, 'tokensdoubler', self.player.tokensdoubler)
        elif self.player.trophy_road == 24:
            DataBase.loadAccount(self)
            count = 10
            LogicTicketsDataCommand(self.client, self.player, count).send()
            self.player.tickets += count
            DataBase.replaceValue(self, "tickets", self.player.tickets)
        elif self.player.trophy_road in [9, 13, 17, 22, 28, 30, 34, 38, 43, 47, 53, 56, 59, 61, 64, 68, 72, 76, 82]:
            if self.player.trophy_road in [9, 13, 17, 22, 30, 34, 43, 47, 53, 56, 59, 61, 64, 72, 76, 82]:
                count = 25
                ShopResponse(self.client, self.player, 1, {"id": 6, "scid": self.brawlerID}, count).send()
                self.player.brawlers_upgradium[str(self.brawlerID)] += count
                DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
            elif self.player.trophy_road in [28, 68]:
                count = 75
                ShopResponse(self.client, self.player, 1, {"id": 6, "scid": self.brawlerID}, count).send()
                self.player.brawlers_upgradium[str(self.brawlerID)] += count
                DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
            elif self.player.trophy_road == 38:
                count = 150
                ShopResponse(self.client, self.player, 1, {"id": 6, "scid": self.brawlerID}, count).send()
                self.player.brawlers_upgradium[str(self.brawlerID)] += count
                DataBase.replaceValue(self, 'brawlersUpgradePoints', self.player.brawlers_upgradium)
        elif self.player.trophy_road in [2, 6, 10, 15, 25, 35, 45, 55, 65, 75]:
            if self.player.trophy_road == 2:
                LogicBrawlerDataCommand(self.client, self.player, 8, 1).send()
            elif self.player.trophy_road == 6:
                LogicBrawlerDataCommand(self.client, self.player, 1, 1).send()
            elif self.player.trophy_road == 10:
                LogicBrawlerDataCommand(self.client, self.player, 2, 1).send()
            elif self.player.trophy_road == 15:
                LogicBrawlerDataCommand(self.client, self.player, 7, 1).send()
            elif self.player.trophy_road == 25:
                LogicBrawlerDataCommand(self.client, self.player, 3, 1).send()
            elif self.player.trophy_road == 35:
                LogicBrawlerDataCommand(self.client, self.player, 9, 1).send()
            elif self.player.trophy_road == 45:
                LogicBrawlerDataCommand(self.client, self.player, 14, 1).send()
            elif self.player.trophy_road == 55:
                LogicBrawlerDataCommand(self.client, self.player, 22, 1).send()
            elif self.player.trophy_road == 65:
                LogicBrawlerDataCommand(self.client, self.player, 27, 1).send()
            elif self.player.trophy_road == 75:
                LogicBrawlerDataCommand(self.client, self.player, 30, 1).send()
        print(self.player.trophy_road)
        self.player.trophy_road += 1
        DataBase.replaceValue(self, "trophyRoad", self.player.trophy_road)
        #DataBase.loadAccount(self)