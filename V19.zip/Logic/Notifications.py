class Notifications:
    """
    << Notification IDs List >>
    
    81 = Custom Message
    82 = Club Message
    74 = Ticket Compensation Message
    77 = ???
    79 = Season End
    
    """



    messages = [

        {
            'NotificationID': 81,
            'NotificationIndex': 3,
            'NotificationRead': False,
            'NotificationTime': 0,
            'NotificationText': f'Welcome to Gale Brawl\nНаш телеграм каналл \n:@GaleBrawll',
            'NotificationType': 0
        },

        {
            'NotificationID': 82,
            'NotificationIndex': 3,
            'NotificationRead': True,
            'NotificationTime': 0,
            'SenderName': 't.me/galebrawll',
            'SenderThumbnail': 0,
            'SenderNameColor': 6,
            'NotificationText': f'Обратная связь с разработчиком: @Shuvee_Dev'
        },

    ]
    
    def EncodeNotificationsMessages(self):
        count = len(Notifications.messages)
        self.writeVint(count) # Count
        for i in range(count):
            item = Notifications.messages[i]
            
            self.writeVint(item['NotificationID'])
            self.writeInt(item['NotificationIndex'])
            self.writeBoolean(item['NotificationRead'])
            self.writeInt(item['NotificationTime'])
            self.writeString(item['NotificationText'])
            
            if item['NotificationID'] == 81:
                self.writeVint(item['NotificationType']) # 0 - Support Service, 1 - System

            elif item['NotificationID'] == 82:
                self.writeString(item['SenderName'])
                self.writeVint(100)
                self.writeVint(28000000 + item['SenderThumbnail'])
                self.writeVint(43000000 + item['SenderNameColor'])
                #self.writeVint(-1)
            
            elif item['NotificationID'] == 74:
                self.writeVint(item['Tickets'])
                self.writeVint(item['Gems'])
            
            elif item['NotificationID'] == 77:
                self.writeVint(0)
                for i in range(1):
                    self.writeVint(1)
                    self.writeVint(14)  # ItemType
                    self.writeVint(1)
                    self.writeVint(0)  # CsvID
                    self.writeVint(0)
                self.writeVint(7)
                self.writeVint(3)
                self.writeString('SUMMER SPORTS CHALLENGE!')

            elif item['NotificationID'] == 79:
                self.writeVint(len(item['Brawlers'])) # Brawlers Count
                for brawler in range(len(item['Brawlers'])):
                    self.writeVint(16000000 + brawler) # Brawler ID
                    self.writeVint(item['TrophiesPlus'][brawler]) # Brawler Trophies
                    self.writeVint(item['TrophiesMinus'][brawler]) # Brawler Trophy Loss
                    self.writeVint(item['Starpoints'][brawler]) # Star Points Gained
